import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import DetailCopy from './Component/DetailCopy';

function App() {
  return (

    <div>

      <div className="container">
        <DetailCopy />
      </div>

    </div>
  );
}

export default App;
