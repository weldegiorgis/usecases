package com.nathy.app.command.api.data;

public enum BidEventType {
	NEW,
	UPDATE

}
