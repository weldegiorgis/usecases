package com.nathy.app.command.api.exception;
 

//public class BidServiceEventsErrorHandler implements ListenerInvocationErrorHandler {
////    @Override
////    public void onError(Exception exception, EventMessage<?> event, EventMessageHandler eventHandler) throws Exception {
////        throw exception;
////    }
//}
