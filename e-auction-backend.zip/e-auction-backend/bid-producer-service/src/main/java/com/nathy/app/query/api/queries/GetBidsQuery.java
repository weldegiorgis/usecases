package com.nathy.app.query.api.queries;

public class GetBidsQuery {
}
