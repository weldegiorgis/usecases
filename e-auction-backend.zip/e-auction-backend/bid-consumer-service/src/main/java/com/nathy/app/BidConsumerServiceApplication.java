package com.nathy.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class BidConsumerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BidConsumerServiceApplication.class, args);
	}

}
