package com.nathy.app.entity;

public enum BidEventType {
	NEW,
	UPDATE

}
