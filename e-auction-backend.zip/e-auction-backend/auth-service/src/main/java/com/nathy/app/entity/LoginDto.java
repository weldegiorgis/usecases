package com.nathy.app.entity;

import lombok.Data;

@Data
public class LoginDto {
	private String username;
	private String password;

}
